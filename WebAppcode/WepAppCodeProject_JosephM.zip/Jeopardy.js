// comment noon java?
// onEvent("displays", "click", function( ) {
//   console.log("help");
// }); 

console.log("js1");

var audio= new Audio("https://codehs.com/uploads/7abf7244ac4d20cdc3b5f0566fcb2b03");
audio.play();