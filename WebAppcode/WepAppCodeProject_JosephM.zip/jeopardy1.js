var audio= new Audio("https://codehs.com/uploads/7008526c202cb2249273467ee80db887");
audio.play();